#!/usr/bin/env bash
#
# 00-lab-up.sh
# ============
# Что делаем: поднимаем стенд «client — router — server» из трёх network
# namespaces внутри ОДНОЙ VM. Это та же топология, что в ДЗ (HW21):
# клиент снаружи, inetRouter2 посередине, nginx за ним.
#
# Целевой ага-эффект: «три машины» за 2 секунды без Vagrant. Namespace —
# это отдельный сетевой стек: свои интерфейсы, маршруты И СВОЙ iptables.
# Всё, что мы дальше делаем с iptables роутера, делается ВНУТРИ ns router
# и не трогает iptables самой VM (ssh до VM не отвалится).
#
# Идемпотентен: если стенд уже есть — сносит и строит заново.
# Время: ~2 минуты с объяснением.

set -euo pipefail
source "$(dirname "$0")/lab-env.sh"

# Зависимости: iproute2, iptables, python3, curl — есть в Ubuntu из коробки.
# ipset и conntrack — нет. Ставим заранее (нужны в 02 и 04):
#     sudo apt install -y ipset conntrack
for b in ip iptables python3 curl nc; do
    command -v "$b" >/dev/null || { echo "✗ нет $b"; exit 1; }
done
for b in ipset conntrack; do
    command -v "$b" >/dev/null || echo "⚠ нет $b — sudo apt install -y ipset conntrack"
done

# Снести старый стенд, если был (молча).
bash "$(dirname "$0")/99-lab-down.sh" >/dev/null 2>&1 || true
mkdir -p "$LAB_DIR"

step "1. Три namespace"
# ip netns add <имя> — создаёт файл /run/netns/<имя>, за ним живёт сетевой стек.
for ns in "$NS_C" "$NS_R" "$NS_S"; do
    run sudo ip netns add "$ns"
    sudo ip netns exec "$ns" ip link set lo up
done
run sudo ip netns list

step "2. Два «провода» (veth-пары) и раскладка концов по namespace"
# veth — виртуальный кабель с двумя концами. Что вошло в один — вышло из другого.
run sudo ip link add c-eth0 type veth peer name r-eth-c
run sudo ip link add s-eth0 type veth peer name r-eth-s
# Переносим концы в нужные ns и сразу даём им «человеческие» имена.
sudo ip link set c-eth0  netns "$NS_C" name eth0
sudo ip link set r-eth-c netns "$NS_R" name eth-c
sudo ip link set r-eth-s netns "$NS_R" name eth-s
sudo ip link set s-eth0  netns "$NS_S" name eth0

step "3. Адреса и маршруты"
inc ip addr add "$C_IP/24"   dev eth0
inr ip addr add "$R_IP_C/24" dev eth-c
inr ip addr add "$R_IP_S/24" dev eth-s
ins ip addr add "$S_IP/24"   dev eth0
inc ip link set eth0 up
inr ip link set eth-c up
inr ip link set eth-s up
ins ip link set eth0 up
# Клиент и сервер ходят «в мир» через роутер.
inc ip route add default via "$R_IP_C"
ins ip route add default via "$R_IP_S"

step "4. Роутер становится роутером"
# Без ip_forward=1 ядро НЕ пересылает пакеты между интерфейсами —
# транзит просто дропается, ещё до iptables FORWARD.
# Это ключ ДЗ: на inetRouter2 тоже нужен net.ipv4.ip_forward=1.
run inr sysctl -w net.ipv4.ip_forward=1

step "5. «nginx» на сервере"
# python3 -m http.server — пишет в лог IP каждого клиента. Это нам и нужно:
# в 02 будем смотреть, КТО пришёл к серверу — клиент или роутер.
# -u — без буферизации, чтобы строки лога появлялись сразу.
mkdir -p "$LAB_DIR/www"
echo "hello from server ($S_IP)" > "$LAB_DIR/www/index.html"
: > "$HTTP_LOG"
ins sh -c "nohup python3 -u -m http.server 80 --bind $S_IP --directory $LAB_DIR/www \
    >>$HTTP_LOG 2>&1 </dev/null &"
sleep 1

step "Проверка"
inc ip -br addr show eth0
inr ip -br addr
ins ip -br addr show eth0
echo
inc ping -c 1 -W 1 "$S_IP" | grep -E 'bytes from|loss'
http_from_client "http://$S_IP/"
echo
echo "✓ Стенд поднят. Лог сервера: tail -f $HTTP_LOG"
