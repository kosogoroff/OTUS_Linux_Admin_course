#!/usr/bin/env bash
#
# lab-env.sh
# ==========
# Общие переменные и хелперы для всех демо урока. Подключается так:
#
#     source "$(dirname "$0")/lab-env.sh"
#
# Сам по себе ничего не создаёт и не ломает.
#
# СТЕНД (повторяет домашку HW21, но в ОДНОЙ VM — через network namespaces):
#
#   ┌─────────────┐  veth   ┌────────────────────────┐  veth   ┌──────────────┐
#   │ ns client   │─────────│ ns router (inetRouter2)│─────────│ ns server    │
#   │ eth0        │         │ eth-c          eth-s   │         │ eth0         │
#   │ 10.0.1.2/24 │         │ 10.0.1.1   10.0.2.1    │         │ 10.0.2.2/24  │
#   └─────────────┘         └────────────────────────┘         │ http.server  │
#                                                              │ :80 (≈nginx) │
#                                                              └──────────────┘
#
# У каждого namespace СВОЙ стек: свои интерфейсы, маршруты, свой iptables,
# свой conntrack, свои ipset'ы. iptables хоста на стенд не влияет и наоборот.

NS_C=client
NS_R=router
NS_S=server

C_IP=10.0.1.2        # клиент
R_IP_C=10.0.1.1      # роутер, нога в сторону клиента («внешняя»)
R_IP_S=10.0.2.1      # роутер, нога в сторону сервера («внутренняя»)
S_IP=10.0.2.2        # сервер (nginx в ДЗ)
FAKE_GW=10.0.2.254   # «другой роутер» (centralRouter в ДЗ) — в 02 сюда уводим default сервера

LAB_DIR=/tmp/iptables-lab           # логи и pid-ы стенда
HTTP_LOG=$LAB_DIR/http-server.log   # здесь http.server пишет, КТО к нему пришёл

# Короткие обёртки: «выполнить команду внутри namespace».
# Под капотом это просто `sudo ip netns exec <ns> <команда>`.
inc() { sudo ip netns exec "$NS_C" "$@"; }
inr() { sudo ip netns exec "$NS_R" "$@"; }
ins() { sudo ip netns exec "$NS_S" "$@"; }

# Пауза между шагами. AUTO=1 bash 0X-....sh — прогон без остановок.
pause() {
    echo
    if [[ -n "${AUTO:-}" ]]; then echo ">>> $*"; return 0; fi
    read -r -p ">>> $* [Enter] " _ || true
}

# Заголовок шага — чтобы на проекторе было видно, где мы.
step() { echo; echo "=== $* ==="; }

# Заголовок команды: печатаем её перед выполнением — зал видит, ЧТО мы набрали.
run() { echo "\$ $*"; "$@"; }

# Проверка «стенд поднят».
require_lab() {
    if [[ ! -e /run/netns/$NS_R ]]; then
        echo "✗ Стенд не поднят. Сначала: bash 00-lab-up.sh"
        exit 1
    fi
}

# Привести роутер в «чистое» состояние: пустые таблицы, policy ACCEPT,
# нулевые счётчики, ни одного ipset, пустой conntrack.
# Каждое демо начинает с этого — порядок запуска 01..04 не важен.
reset_router() {
    local t
    for t in filter nat mangle raw; do
        inr iptables -t "$t" -F
        inr iptables -t "$t" -X
        inr iptables -t "$t" -Z
    done
    for c in INPUT FORWARD OUTPUT; do inr iptables -P "$c" ACCEPT; done
    if inr sh -c 'command -v ipset' >/dev/null 2>&1; then
        inr ipset destroy 2>/dev/null || true
    fi
    if inr sh -c 'command -v conntrack' >/dev/null 2>&1; then
        inr conntrack -F >/dev/null 2>&1 || true
    fi
    # Сервер по умолчанию знает дорогу домой через роутер (02 это ломает и чинит).
    ins ip route replace default via "$R_IP_S"
}

# HTTP-запрос с клиента: печатает код ответа или «тишина (таймаут)».
# -m 3 : ждать не больше 3 секунд — не висим на проекторе.
http_from_client() {
    local url=$1
    local code
    if code=$(inc curl -s -o /dev/null -w '%{http_code}' -m 3 "$url"); then
        echo "✓ $url → HTTP $code"
    else
        echo "✗ $url → тишина (таймаут 3с)"
    fi
}
