#!/usr/bin/env bash
#
# 03-port-knocking.sh
# ===================
# Что делаем: port knocking на роутере модулем -m recent (пункт ДЗ про
# knocking на inetRouter). «SSH» роутера (у нас tcp/2222) закрыт для всех.
# Клиент «стучит» в tcp/7000 — и в течение 10 секунд 2222 открыт
# ТОЛЬКО ДЛЯ ЕГО IP. Потом снова закрыт.
#
# Целевой ага-эффект: у iptables есть ПАМЯТЬ. -m recent — это список IP
# с метками времени, который ядро ведёт само, и его видно глазами:
#
#     cat /proc/net/xt_recent/KNOCK
#
# Правила не меняются — меняется содержимое списка.
# Время: ~10 минут.
#
# В ДЗ обычно последовательность из 2-3 портов и цепочки TRAFFIC/SSH-INPUT —
# это тот же механизм: несколько списков recent, каждый следующий стук
# проверяет --rcheck предыдущего. Здесь один стук — чтобы было видно суть.

set -euo pipefail
source "$(dirname "$0")/lab-env.sh"
require_lab
reset_router

KNOCK_PORT=7000
SSH_PORT=2222        # «ssh» — чтобы не путать с настоящим sshd VM
OPEN_SECONDS=10
C_IP2=10.0.1.3       # второй адрес клиента — «посторонний» в той же сети

# Проверка порта: TCP-коннект с таймаутом 1с. nc -z = только соединиться.
# Второй аргумент (опц.) — с какого адреса клиента подключаться (-s).
probe() {
    local port=$1 src=${2:-$C_IP}
    if inc nc -z -w 1 -s "$src" "$R_IP_C" "$port" 2>/dev/null; then
        echo "  ✓ $src → $R_IP_C:$port ОТКРЫТ"
    else
        echo "  ✗ $src → $R_IP_C:$port закрыт (таймаут)"
    fi
}
knock() {
    local src=${1:-$C_IP}
    echo "  ♪ $src стучит в $R_IP_C:$KNOCK_PORT"
    inc nc -z -w 1 -s "$src" "$R_IP_C" "$KNOCK_PORT" 2>/dev/null || true
}

# «sshd» на роутере: любой TCP-листенер на 2222. Берём python http.server.
inr sh -c "nohup python3 -m http.server $SSH_PORT --bind $R_IP_C \
    >$LAB_DIR/fake-ssh.log 2>&1 </dev/null &"
inc ip addr add "$C_IP2/24" dev eth0 2>/dev/null || true
sleep 1

step "Шаг 0. Без правил порт $SSH_PORT открыт для всех"
probe "$SSH_PORT"
probe "$SSH_PORT" "$C_IP2"

pause "Ставим knocking"

step "Шаг 1. Правила knocking в INPUT роутера"
# Порядок важен — читаем сверху вниз:
# 1. ответы на уже открытые соединения — пропускаем (см. 01)
run inr iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
run inr iptables -A INPUT -i lo -j ACCEPT
# 2. СТУК: пакет на 7000 → записать src IP в список KNOCK (--set) и выбросить.
#    Стучащий получает таймаут — снаружи порт 7000 выглядит мёртвым.
run inr iptables -A INPUT -p tcp --dport $KNOCK_PORT \
    -m recent --name KNOCK --set -j DROP
# 3. ВХОД: новый коннект на 2222 пускаем, ЕСЛИ src есть в KNOCK
#    и запись не старше 10 секунд (--rcheck --seconds).
run inr iptables -A INPUT -p tcp --dport $SSH_PORT -m conntrack --ctstate NEW \
    -m recent --name KNOCK --rcheck --seconds $OPEN_SECONDS -j ACCEPT
# 4. Остальное на 2222 — в мусор.
run inr iptables -A INPUT -p tcp --dport $SSH_PORT -j DROP

step "Шаг 2. Без стука"
probe "$SSH_PORT"
echo "\$ cat /proc/net/xt_recent/KNOCK"
inr cat /proc/net/xt_recent/KNOCK
echo "  (список пуст)"

pause "Стучим"

step "Шаг 3. Стук → $SSH_PORT открыт только для $C_IP"
knock
echo "\$ cat /proc/net/xt_recent/KNOCK"
inr cat /proc/net/xt_recent/KNOCK
echo "  ↑ src — кто стучал, last_seen — когда (jiffies), дальше — метки времени каждого стука"
probe "$SSH_PORT"
probe "$SSH_PORT" "$C_IP2"
echo "  ↑ тот же порт, та же сеть — но $C_IP2 не стучал."

pause "Ждём $((OPEN_SECONDS + 1)) секунд — окно закроется"

step "Шаг 4. Прошло $((OPEN_SECONDS + 1)) секунд"
sleep $((OPEN_SECONDS + 1))
probe "$SSH_PORT"
echo "  Запись в KNOCK осталась, но она старше --seconds $OPEN_SECONDS → не совпадает."
echo "  Уже установленные соединения живут: их пускает правило ESTABLISHED."

echo
run inr iptables -nvx -L INPUT --line-numbers

cat <<'TXT'

  Управлять списком можно руками, без правок правил (из root-шелла роутера:
  sudo ip netns exec router bash):
    echo +10.0.1.3 > /proc/net/xt_recent/KNOCK   # добавить
    echo -10.0.1.3 > /proc/net/xt_recent/KNOCK   # удалить
    echo /         > /proc/net/xt_recent/KNOCK   # очистить
TXT

inc ip addr del "$C_IP2/24" dev eth0 2>/dev/null || true
echo
echo "✓ Готово. «sshd» на $SSH_PORT живёт до 99-lab-down.sh."
