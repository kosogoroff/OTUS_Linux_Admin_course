#!/usr/bin/env bash
#
# 01-forward.sh
# =============
# Что делаем: гоняем трафик client → server ЧЕРЕЗ router и смотрим на
# счётчики цепочек роутера. Потом закрываем транзит (-P FORWARD DROP)
# и открываем его правильно — conntrack ESTABLISHED,RELATED.
#
# Целевой ага-эффект:
#
#     ТРАНЗИТНЫЙ ПАКЕТ НЕ ПРОХОДИТ INPUT.
#     INPUT — только для пакетов «мне». Чужие едут через FORWARD.
#
# Типовая ошибка в ДЗ: «закрыл всё в INPUT на inetRouter2, а клиенты
# по-прежнему ходят» — или наоборот, «открыл 80 в INPUT, а DNAT не работает».
# Время: ~10 минут.
#
#              PREROUTING ──► решение маршрутизации ──► FORWARD ──► POSTROUTING
#                                     │ (пакет мне?)
#                                     ▼
#                                   INPUT ──► локальный процесс

set -euo pipefail
source "$(dirname "$0")/lab-env.sh"
require_lab
reset_router

# --- ШАГ 1. Счётчики ------------------------------------------------------

step "Шаг 1. Пакет ЧЕРЕЗ роутер: смотрим счётчики"

# Добавляем «пустые» правила без -j — они ничего не делают, только считают.
# Это удобный приём отладки: «а сюда вообще пакеты доходят?»
inr iptables -A INPUT   -m comment --comment "счётчик INPUT"
inr iptables -A FORWARD -m comment --comment "счётчик FORWARD"

echo "### client → server: 3 пинга + HTTP"
inc ping -c 3 -W 1 "$S_IP" | grep -E 'loss'
http_from_client "http://$S_IP/"

pause "Ставка в чат: какой счётчик на роутере вырос — 1) INPUT 2) FORWARD"
# -n : не резолвить имена, -v : показать счётчики pkts/bytes, -x : точные числа
run inr iptables -nvx -L INPUT
echo
run inr iptables -nvx -L FORWARD

cat <<'TXT'

  Вопрос в зал: пакеты шли «на роутер» или «через роутер»?
  FORWARD вырос, INPUT — ноль. Транзитный пакет в INPUT не попадает.
TXT

pause "Теперь пакет НА сам роутер — для контраста"

inr iptables -Z
echo "### client → router (10.0.1.1): 3 пинга"
inc ping -c 3 -W 1 "$R_IP_C" | grep -E 'loss'
run inr iptables -nvx -L INPUT
run inr iptables -nvx -L FORWARD
echo
echo "  Теперь наоборот: INPUT вырос, FORWARD — ноль."

pause "Закрываем транзит"

# --- ШАГ 2. Policy DROP ---------------------------------------------------

step "Шаг 2. -P FORWARD DROP"
inr iptables -F
# Policy — что делать с пакетом, который не совпал ни с одним правилом.
# Для роутера разумный дефолт — DROP: пересылаем только то, что разрешили.
run inr iptables -P FORWARD DROP
http_from_client "http://$S_IP/"
inr iptables -nvx -L FORWARD
echo "  ↑ счётчик policy растёт: пакеты дошли до FORWARD и умерли там."

pause "Наивно разрешаем «client → server :80»"

# --- ШАГ 3. Наивно: только «туда» ----------------------------------------

step "Шаг 3. Разрешаем только направление client → server"
# -i вход, -o выход — для FORWARD указываются ОБА, это и есть «направление».
run inr iptables -A FORWARD -i eth-c -o eth-s -p tcp --dport 80 -j ACCEPT
http_from_client "http://$S_IP/"
run inr iptables -nvx -L FORWARD

cat <<'TXT'

  SYN ушёл к серверу (счётчик правила > 0), а ответ SYN-ACK идёт
  в обратную сторону: -i eth-s -o eth-c. Под правило не попадает →
  policy DROP. Тот же сюжет, что с INPUT в базовом уроке:
  ОТВЕТ — ЭТО ТОЖЕ ПАКЕТ, и он тоже идёт через FORWARD.
TXT

pause "Чиним правильно — conntrack"

# --- ШАГ 4. conntrack -----------------------------------------------------

step "Шаг 4. ESTABLISHED,RELATED первым правилом"
# Пропускать всё, что относится к уже разрешённым соединениям — в ОБЕ стороны.
# Ставим ПЕРВЫМ (-I FORWARD 1): большинство пакетов на роутере — именно такие.
run inr iptables -I FORWARD 1 -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
# А новые соединения — только то, что разрешили явно. Уточняем NEW.
inr iptables -R FORWARD 2 -i eth-c -o eth-s -p tcp --dport 80 \
    -m conntrack --ctstate NEW -j ACCEPT
inr iptables -Z FORWARD
http_from_client "http://$S_IP/"
echo
run inr iptables -nvx -L FORWARD --line-numbers

cat <<'TXT'

  Правило 2 (NEW) — 1 пакет: только SYN. Всё остальное соединение
  (данные, ACK-и, ответы сервера) — правило 1 (ESTABLISHED).

  А ping? Его мы не разрешали:
TXT
inc ping -c 2 -W 1 "$S_IP" | grep -E 'loss' || true

echo
echo "✓ Готово. Итоговые правила роутера:"
run inr iptables -S
