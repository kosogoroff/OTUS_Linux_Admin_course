# iptables на роутере — шпаргалка

Занятие 30 «Фильтрация трафика — iptables», Linux Professional. Ubuntu 26.04, iptables v1.8.11 (nf_tables).
Всё от root (`sudo`). На стенде урока префикс `inr` / `inc` / `ins` = `sudo ip netns exec router|client|server`.

```bash
sudo apt install -y ipset conntrack     # из коробки их нет
```

## Путь пакета

```
PREROUTING (DNAT) → маршрут: мне? ─да→ INPUT → процесс → OUTPUT ─┐
                                 └нет→ FORWARD ───────────────────┴→ POSTROUTING (SNAT/MASQUERADE)
```

**Мне — INPUT, через меня — FORWARD, от меня — OUTPUT. DNAT — до маршрутизации, SNAT — после.**
nat видит только первый пакет соединения, остальное переводит conntrack.

## Роутер: FORWARD + conntrack

```bash
sysctl -w net.ipv4.ip_forward=1                      # без этого транзита нет вообще
iptables -P FORWARD DROP
iptables -A FORWARD -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT   # первой строкой
iptables -A FORWARD -i eth-c -o eth-s -p tcp -d 10.0.2.2 --dport 80 \
         -m conntrack --ctstate NEW -j ACCEPT       # решаем только про NEW
```

## NAT: проброс порта

```bash
# DNAT: router:8080 → server:80
iptables -t nat -A PREROUTING -i eth-c -p tcp --dport 8080 -j DNAT --to-destination 10.0.2.2:80

# Фикс A — сервер видит IP роутера:
iptables -t nat -A POSTROUTING -o eth-s -p tcp -d 10.0.2.2 --dport 80 -j MASQUERADE
iptables -t nat -A POSTROUTING -o eth-s -p tcp -d 10.0.2.2 --dport 80 -j SNAT --to-source 10.0.2.1  # то же, адрес фиксирован

# Фикс B (без маскарадинга*) — на СЕРВЕРЕ, сервер видит IP клиента:
ip route add 10.0.1.0/24 via 10.0.2.1

# Удалить правило — та же строка с -D вместо -A:
iptables -t nat -D POSTROUTING -o eth-s -p tcp -d 10.0.2.2 --dport 80 -j MASQUERADE
```

Правило FORWARD для проброса — на **внутренний** адрес/порт (80), не на 8080.

## Диагностика «проброс стоит, а молчит»

```bash
sysctl net.ipv4.ip_forward                   # 1?
iptables -t nat -nvx -L PREROUTING           # счётчик DNAT растёт? (строка правила, не policy)
iptables -nvx -L FORWARD --line-numbers      # транзит пропущен? растёт policy?
conntrack -L -p tcp --dport 8080             # [UNREPLIED] = ответ не вернулся через роутер
ip route get 10.0.1.2                        # на сервере: куда уйдёт ответ клиенту
ss -tn state syn-recv                        # на сервере: SYN пришёл, рукопожатие не завершилось
conntrack -F                                 # очистить таблицу соединений
iptables -Z                                  # обнулить счётчики
iptables -A FORWARD -m comment --comment cnt # правило без -j = просто счётчик
```

- `/proc/net/nf_conntrack` в ядре Ubuntu нет — только `conntrack -L`.
- `curl localhost:8080` на самом роутере DNAT не проверяет (локальное идёт через OUTPUT). Проверяйте снаружи.

## Port knocking (`-m recent`)

```bash
iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -p tcp --dport 7000 -m recent --name KNOCK --set -j DROP
iptables -A INPUT -p tcp --dport 22 -m conntrack --ctstate NEW \
         -m recent --name KNOCK --rcheck --seconds 10 -j ACCEPT
iptables -A INPUT -p tcp --dport 22 -j DROP
```

Последовательность 7001 → 7002:

```bash
iptables -A INPUT -p tcp --dport 7001 -m recent --name K1 --set -j DROP
iptables -A INPUT -p tcp --dport 7002 -m recent --name K1 --rcheck --seconds 5 \
         -m recent --name K2 --set -j DROP
iptables -A INPUT -p tcp --dport 22 -m conntrack --ctstate NEW \
         -m recent --name K2 --rcheck --seconds 10 -j ACCEPT
iptables -A INPUT -p tcp --dport 22 -j DROP
```

```bash
cat /proc/net/xt_recent/KNOCK                     # кто стучал и когда
echo / | sudo tee /proc/net/xt_recent/KNOCK        # очистить (+IP добавить, -IP удалить)

nc -z -w1 10.0.1.1 7000                            # постучать
nmap -Pn --max-retries 0 -p 7000 10.0.1.1          # то же через nmap
timeout 1 bash -c 'echo > /dev/tcp/10.0.1.1/7000'  # то же чистым bash
```

⚠️ В Vagrant не закрывайте 22 на eth0 (через него `vagrant ssh` и Ansible): ставьте `-i <интерфейс к centralRouter>`.

## ipset

```bash
ipset create blacklist hash:net                  # hash:ip — адреса, hash:net — подсети, hash:ip,port
ipset create tmpban hash:ip timeout 300          # элементы истекают сами
iptables -A FORWARD -m set --match-set blacklist src -j DROP   # src / dst

ipset add  blacklist 10.0.1.0/24
ipset del  blacklist 10.0.1.0/24
ipset test blacklist 10.0.1.2                    # код возврата 0 — в наборе
ipset add  tmpban 203.0.113.5 timeout 60
ipset list blacklist -t                          # заголовок: тип, память, число элементов
ipset restore -f list.txt                        # пачкой: строки «add blacklist <адрес>»
ipset flush blacklist ; ipset destroy blacklist  # destroy — только когда на набор нет правил
```

## Сохранение: сначала ipset, потом iptables

```bash
# сохранить (от root: перенаправление делает шелл)
ipset save    > /etc/iptables/ipsets
iptables-save > /etc/iptables/rules.v4

# загрузить — строго в этом порядке, иначе «Set ... doesn't exist»
ipset restore    < /etc/iptables/ipsets
iptables-restore < /etc/iptables/rules.v4        # атомарный: ошибка → не применит ничего
iptables-restore --test /etc/iptables/rules.v4   # только проверить синтаксис

# при загрузке ОС
apt install -y iptables-persistent ipset-persistent   # удалит ufw — конфликтуют
netfilter-persistent save                             # сохранить текущее (ipset раньше iptables)
```

- `iptables-save` наборы ipset **не сохраняет**.
- `iptables-restore` заменяет каждую таблицу из файла целиком — в файле должен быть полный набор правил хоста.
- Ansible: `template` → `/etc/iptables/rules.v4` (`validate: iptables-restore --test %s`) + handler на перезапуск `netfilter-persistent`. `ip_forward` — файлом в `/etc/sysctl.d/`.
