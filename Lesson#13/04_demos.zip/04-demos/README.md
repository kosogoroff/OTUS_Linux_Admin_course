# Демо урока 30 «Фильтрация трафика — iptables» (Linux Professional)

Весь стенд — в **одной VM** (Ubuntu 26.04, iptables 1.8.11 nft) через network namespaces.
Топология повторяет ДЗ HW21:

```
client (ns client)        router = inetRouter2 (ns router)        server (ns server)
10.0.1.2 ──────── eth-c 10.0.1.1 │ 10.0.2.1 eth-s ──────── 10.0.2.2  python3 -m http.server 80 (≈ nginx)
```

У каждого ns свой iptables / conntrack / ipset — iptables самой VM не трогаем, ssh не отвалится.

## Подготовка (один раз, до урока)

```bash
sudo apt install -y ipset conntrack        # curl, nc, python3 — уже есть
cd ~/…/linux-prof/iptables/lesson/04-demos
```

## Порядок

| Скрипт | Что показывает | Ага-эффект |
|---|---|---|
| `00-lab-up.sh` | Поднимает 3 ns, 2 veth, адреса, `ip_forward=1` в router, http.server в server. Идемпотентен (пересоздаёт). | «три машины за 2 секунды» |
| `01-forward.sh` | Счётчики: транзит растит FORWARD, не INPUT. `-P FORWARD DROP` → наивное «туда» не чинит → `ESTABLISHED,RELATED` чинит. | **транзитный пакет не проходит INPUT** |
| `02-dnat-port-forward.sh` | DNAT router:8080→server:80 при default сервера «не туда» → тишина (`[UNREPLIED]`, `SYN-RECV`). Фикс A: MASQUERADE (в логе 10.0.2.1). Фикс B: обратный маршрут (в логе 10.0.1.2). | **DNAT без обратного пути — тишина** |
| `03-port-knocking.sh` | `-m recent`: стук в tcp/7000 → tcp/2222 открыт 10 с только для стучавшего IP. `/proc/net/xt_recent/KNOCK`. | у iptables есть память |
| `04-ipset.sh` | 1000 IP: 1000 правил (`iptables -S \| wc -l` = 1003) vs 1 правило + `hash:net` (= 4). add/del на живую. | список — это данные, а не правила |
| `99-lab-down.sh` | Убивает процессы в ns, удаляет ns. Идемпотентен. | |

Каждое демо 01–04 начинает с `reset_router` (пустые таблицы, policy ACCEPT, без ipset) — их можно запускать в любом порядке и повторно.
`lab-env.sh` — общие переменные и хелперы (`inc`/`inr`/`ins` = `sudo ip netns exec client|router|server`), подключается всеми.

```bash
bash 00-lab-up.sh
bash 01-forward.sh
bash 02-dnat-port-forward.sh
bash 03-port-knocking.sh
bash 04-ipset.sh
bash 99-lab-down.sh
```

`AUTO=1 bash 0X-….sh` — прогон без пауз (репетиция). Лог «nginx»: `tail -f /tmp/iptables-lab/http-server.log`.
Поработать руками внутри роутера: `sudo ip netns exec router bash`.

## Уборка

`bash 99-lab-down.sh` — и в VM не остаётся ничего: ns, veth, правила, ipset и conntrack живут внутри ns и умирают вместе с ним. `/tmp/iptables-lab` удаляется.

## Шпаргалка

```bash
# --- namespaces
ip netns add r; ip netns exec r <cmd>; ip netns pids r; ip netns del r
ip link add a type veth peer name b; ip link set b netns r name eth0
ip netns exec r sysctl -w net.ipv4.ip_forward=1

# --- счётчики / отладка
iptables -nvx -L FORWARD --line-numbers     # -v счётчики, -x точные числа
iptables -Z                                  # обнулить счётчики
iptables -A INPUT -m comment --comment cnt   # правило без -j = просто счётчик
iptables -t nat -nvx -L                      # nat видит только ПЕРВЫЙ пакет соединения
conntrack -L -p tcp ; conntrack -F           # [UNREPLIED] = ответа не было

# --- роутер
iptables -P FORWARD DROP
iptables -A FORWARD -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
iptables -A FORWARD -i eth-c -o eth-s -p tcp --dport 80 -m conntrack --ctstate NEW -j ACCEPT

# --- проброс порта (ДЗ п.4)
iptables -t nat -A PREROUTING  -i eth-c -p tcp --dport 8080 -j DNAT --to-destination 10.0.2.2:80
iptables -t nat -A POSTROUTING -o eth-s -p tcp -d 10.0.2.2 --dport 80 -j MASQUERADE   # фикс A
ip route add 10.0.1.0/24 via 10.0.2.1        # фикс B (на сервере): ответ через тот же роутер

# --- port knocking
iptables -A INPUT -p tcp --dport 7000 -m recent --name KNOCK --set -j DROP
iptables -A INPUT -p tcp --dport 22 -m conntrack --ctstate NEW \
         -m recent --name KNOCK --rcheck --seconds 10 -j ACCEPT
iptables -A INPUT -p tcp --dport 22 -j DROP
cat /proc/net/xt_recent/KNOCK ; echo / > /proc/net/xt_recent/KNOCK
nc -z -w1 10.0.1.1 7000                      # постучать

# --- ipset
ipset create blacklist hash:net              # hash:ip, hash:net, hash:ip,port …; timeout 300
ipset add blacklist 10.0.1.0/24 ; ipset del blacklist 10.0.1.0/24 ; ipset test blacklist 10.0.1.2
ipset list blacklist -t ; ipset restore -f file ; ipset save > /etc/iptables/ipsets
iptables -A FORWARD -m set --match-set blacklist src -j DROP
```
