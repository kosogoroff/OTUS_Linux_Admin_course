#!/usr/bin/env bash
#
# 04-ipset.sh
# ===========
# Что делаем: блокируем на роутере список из 1000 «плохих» IP двумя способами:
#   A. 1000 правил iptables — по правилу на адрес;
#   B. одно правило `-m set --match-set` + ipset hash:net на 1000 элементов.
# Потом добавляем/удаляем адрес «на живую» — правила не трогаем вообще.
#
# Целевой ага-эффект:
#
#     СПИСОК — ЭТО ДАННЫЕ, А НЕ ПРАВИЛА.
#     1000 правил — это 1000 проверок на КАЖДЫЙ пакет подряд (линейно)
#     и простыня в iptables -S. ipset — хеш-таблица: одна проверка,
#     одно правило, а список меняется без перезагрузки правил.
#
# Время: ~10 минут. Нужен пакет ipset: sudo apt install -y ipset

set -euo pipefail
source "$(dirname "$0")/lab-env.sh"
require_lab
command -v ipset >/dev/null || { echo "✗ нет ipset: sudo apt install -y ipset"; exit 1; }
reset_router

N=1000
LIST=$LAB_DIR/bad-ips.txt
# 1000 случайных уникальных адресов из 100.64.0.0/10 (CGNAT — в наш стенд не попадут).
python3 -c "
import random; random.seed(30)
s=set()
while len(s)<$N: s.add('100.%d.%d.%d'%(random.randint(64,127),random.randint(0,255),random.randint(1,254)))
print('\n'.join(sorted(s)))" > "$LIST"
echo "### Список: $(wc -l < "$LIST") адресов, первые три:"
head -3 "$LIST"

# --- A. 1000 правил -------------------------------------------------------

step "A. По правилу на каждый адрес"
# Через цикл `iptables -A` × 1000 это долго (каждый вызов перечитывает весь
# ruleset). Грузим пачками через iptables-restore --noflush — как это делали
# бы в жизни. Результат в ядре тот же самый: 1000 правил.
# Пачки по 200 — одна транзакция на 1000 правил может упереться в размер
# netlink-буфера («Message too long»), особенно в контейнерах.
rm -f "$LAB_DIR"/rules-part-*
split -l 200 -d "$LIST" "$LAB_DIR/rules-part-"
time for part in "$LAB_DIR"/rules-part-*; do
    { echo "*filter"; sed 's/.*/-A FORWARD -s & -j DROP/' "$part"; echo "COMMIT"; } \
        | inr iptables-restore --noflush
done

echo
echo "\$ inr iptables -S | wc -l"
inr iptables -S | wc -l
echo "\$ inr iptables -S FORWARD | head -4"
inr iptables -S FORWARD | sed -n '1,4p'
echo "  ..."
cat <<'TXT'

  Каждый транзитный пакет (в т.ч. ЛЕГИТИМНЫЙ) проходит до 1000 сравнений,
  пока не дойдёт до конца цепочки. И чтобы убрать один адрес из «бана» —
  надо искать и удалять конкретное правило.
TXT

pause "Тот же список через ipset"

# --- B. ipset -------------------------------------------------------------

step "B. ipset hash:net + одно правило"
inr iptables -F FORWARD
# create <имя> <тип>:
#   hash:ip  — отдельные адреса
#   hash:net — адреса И подсети (10.0.0.0/8 тоже можно положить)
run inr ipset create blacklist hash:net
# Пачкой — через ipset restore (формат: «add <set> <элемент>» построчно).
sed 's/^/add blacklist /' "$LIST" > "$LAB_DIR/ipset-1000.txt"
time inr ipset restore -f "$LAB_DIR/ipset-1000.txt"
echo
# -t (terse) — только заголовок: тип, размер в памяти, число элементов.
run inr ipset list blacklist -t

# Одно правило. src — сравнивать адрес ИСТОЧНИКА пакета (dst — назначения).
run inr iptables -A FORWARD -m set --match-set blacklist src -j DROP
echo
echo "\$ inr iptables -S | wc -l"
inr iptables -S | wc -l
run inr iptables -S FORWARD

pause "Проверяем, что правило реально работает — баним клиента"

# --- C. Живое изменение списка --------------------------------------------

step "C. add/del на живую — правила не трогаем"
inr iptables -Z FORWARD
http_from_client "http://$S_IP/"

echo
# Кладём сеть клиента целиком — hash:net это умеет.
run inr ipset add blacklist 10.0.1.0/24
run inr ipset test blacklist "$C_IP" || true
http_from_client "http://$S_IP/"
run inr iptables -nvx -L FORWARD
echo "  ↑ счётчик единственного правила растёт — это дропы клиента."

pause "Разбаниваем"

run inr ipset del blacklist 10.0.1.0/24
http_from_client "http://$S_IP/"
echo
echo "  Правило за всё это время не менялось:"
run inr iptables -S FORWARD

cat <<'TXT'

  Заметки на полях:
  • ipset живёт отдельно от iptables: iptables-save его НЕ сохраняет.
    Сохранять: ipset save > /etc/iptables/ipsets (пакет ipset-persistent
    или netfilter-persistent с плагином) — и грузить ДО правил, иначе
    iptables-restore упадёт: «Set blacklist doesn't exist».
  • Удалить set, на который ссылается правило, нельзя: сначала правило.
  • Таймауты элементов: ipset create tmp hash:ip timeout 300 —
    «бан на 5 минут» без cron-а. Так работают fail2ban (action ipset) и crowdsec.
TXT

echo
echo "✓ Готово."
