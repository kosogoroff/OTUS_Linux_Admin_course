#!/usr/bin/env bash
#
# 02-dnat-port-forward.sh
# =======================
# Что делаем: пункт 4 ДЗ — «проброс порта»: router:8080 → server:80
# (в ДЗ: inetRouter2:8080 → nginx на centralServer:80).
#
#   1. Ставим DNAT — и при этом у сервера default route смотрит НЕ на наш
#      роутер, а на «другой» (как centralServer в ДЗ ходит наружу через
#      centralRouter → inetRouter, а не через inetRouter2). → Тишина.
#   2. Фикс A: SNAT/MASQUERADE на роутере. Работает, но сервер видит
#      в логе IP роутера, а не клиента.
#   3. Фикс B («без маскарадинга*» из ДЗ): даём серверу обратный путь
#      через роутер. Работает, и сервер видит НАСТОЯЩИЙ IP клиента.
#
# Целевой ага-эффект:
#
#     DNAT БЕЗ ОБРАТНОГО ПУТИ — ТИШИНА.
#     DNAT меняет только адрес назначения. Ответ сервер шлёт по СВОЕЙ
#     таблице маршрутизации. Если ответ уехал мимо роутера — обратный
#     NAT (un-DNAT) сделать некому, и клиент ответа не узнает.
#
# Время: ~15 минут.

set -euo pipefail
source "$(dirname "$0")/lab-env.sh"
require_lab
reset_router
: > "$HTTP_LOG"   # чистим лог сервера, чтобы видеть только запросы этого демо

# Показ таблицы соединений роутера (conntrack-tools, иначе /proc).
show_ct() {
    echo "\$ inr conntrack -L -p tcp"
    if inr sh -c 'command -v conntrack' >/dev/null; then
        inr conntrack -L -p tcp 2>/dev/null || true
    else
        inr cat /proc/net/nf_conntrack 2>/dev/null | grep tcp || echo "(conntrack не установлен: sudo apt install conntrack)"
    fi
}

# Последние строки лога сервера: там IP того, кто реально пришёл.
show_log() {
    echo "\$ tail -n 2 $HTTP_LOG"
    if [[ -s "$HTTP_LOG" ]]; then tail -n 2 "$HTTP_LOG"; else echo "(лог пуст — HTTP-запрос до сервера не дошёл)"; fi
}

# --- ШАГ 0. Ломаем обратный путь (имитируем стенд ДЗ) --------------------

step "Шаг 0. У сервера default — через «другой роутер» $FAKE_GW"
# В ДЗ у centralServer default смотрит на centralRouter, а не на inetRouter2.
# У нас «другого роутера» нет вовсе: ответы уйдут в никуда.
run ins ip route replace default via "$FAKE_GW"
run ins ip route
echo
echo "### Куда сервер отправит ответ клиенту $C_IP?"
run ins ip route get "$C_IP"

pause "Ставим DNAT"

# --- ШАГ 1. Только DNAT ---------------------------------------------------

step "Шаг 1. DNAT router:8080 → server:80"
# -t nat -A PREROUTING : nat-таблица, ДО решения маршрутизации — поэтому
#                        после подмены адреса пакет уйдёт в FORWARD, а не в INPUT.
# -i eth-c             : только то, что пришло «снаружи».
# --to-destination     : новый адрес:порт назначения.
run inr iptables -t nat -A PREROUTING -i eth-c -p tcp --dport 8080 \
    -j DNAT --to-destination "$S_IP:80"
# FORWARD у нас policy ACCEPT (reset_router) — фильтр сейчас не мешает.
# В реальном роутере с -P FORWARD DROP понадобится ещё:
#   iptables -A FORWARD -i eth-c -o eth-s -p tcp -d 10.0.2.2 --dport 80 \
#            -m conntrack --ctstate NEW -j ACCEPT   (+ ESTABLISHED,RELATED, см. 01)

http_from_client "http://$R_IP_C:8080/"
echo
run inr iptables -t nat -nvx -L PREROUTING
echo "  ↑ 1 пакет: nat-таблица видит ТОЛЬКО первый пакет соединения,"
echo "    решение запоминается в conntrack, остальные NAT-ятся оттуда."
echo
show_ct
echo
show_log

cat <<'TXT'

  Читаем conntrack построчно:
    src=10.0.1.2 dst=10.0.1.1 dport=8080      ← что прислал клиент
    src=10.0.2.2 dst=10.0.1.2 sport=80 ...    ← КАКОЙ ОТВЕТ роутер ждёт
    [UNREPLIED]                               ← и так его и не дождался

  Сервер SYN получил и ответил SYN-ACK — но по своему default route,
  на 10.0.2.254. В логе nginx пусто: TCP-рукопожатие не завершилось,
  HTTP-запроса не было. (tcpdump -ni eth0 на сервере показал бы SYN.) Роутер ответа не видел →
  обратную подмену src 10.0.2.2 → 10.0.1.1 сделать некому.
  Даже если бы ответ дошёл до клиента другим путём — клиент ждёт
  ответ от 10.0.1.1:8080, а пакет от 10.0.2.2:80 он выбросит.
TXT
echo
echo "### Доказательства на сервере:"
echo "### 1) полуоткрытое соединение — SYN пришёл, на SYN-ACK ответа нет"
run ins ss -tn state syn-recv
echo "### 2) «другого роутера» 10.0.2.254 нет — ответы уходят в пустоту"
run ins ip neigh show "$FAKE_GW"

pause "Фикс A — маскарадинг"

# --- ШАГ 2. Фикс A: SNAT/MASQUERADE ---------------------------------------

step "Шаг 2. Фикс A: MASQUERADE в сторону сервера"
# Подменяем ещё и ИСТОЧНИК: серверу кажется, что к нему пришёл роутер.
# Отвечает он роутеру (10.0.2.1 — connected сеть, default не нужен) →
# роутер по conntrack делает обратную подмену обоих адресов.
#
# MASQUERADE = SNAT на адрес выходного интерфейса. Для статического IP
# можно точнее: -j SNAT --to-source 10.0.2.1
run inr iptables -t nat -A POSTROUTING -o eth-s -p tcp -d "$S_IP" --dport 80 -j MASQUERADE
http_from_client "http://$R_IP_C:8080/"
echo
show_log
echo
echo "  ↑ сервер видит $R_IP_S — IP роутера. Для логов, rate-limit,"
echo "    allow/deny по IP на nginx — это потеря информации."

pause "Фикс B — без маскарадинга"

# --- ШАГ 3. Фикс B: обратный маршрут --------------------------------------

step "Шаг 3. Фикс B: без MASQUERADE, но с обратным путём"
run inr iptables -t nat -D POSTROUTING -o eth-s -p tcp -d "$S_IP" --dport 80 -j MASQUERADE
# Достаточно, чтобы ответ клиенту шёл ЧЕРЕЗ ТОТ ЖЕ роутер.
# Можно точечно: ip route add 10.0.1.0/24 via 10.0.2.1
# В ДЗ (где default у сервера обязан остаться на centralRouter) то же самое
# делают policy routing'ом или маршрутом на centralRouter — суть одна:
# ОТВЕТ ДОЛЖЕН ВЕРНУТЬСЯ ЧЕРЕЗ ТОТ РОУТЕР, КОТОРЫЙ СДЕЛАЛ DNAT.
run ins ip route add 10.0.1.0/24 via "$R_IP_S"
run ins ip route get "$C_IP"
http_from_client "http://$R_IP_C:8080/"
echo
show_log
echo
echo "  ↑ сервер видит $C_IP — настоящий IP клиента."
echo
run inr iptables -t nat -S

# Вернуть серверу нормальный default (на случай запуска других демо).
ins ip route del 10.0.1.0/24 via "$R_IP_S" 2>/dev/null || true
ins ip route replace default via "$R_IP_S"
echo
echo "✓ Готово. Маршруты сервера возвращены в исходное."
