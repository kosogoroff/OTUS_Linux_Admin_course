#!/usr/bin/env bash
#
# 99-lab-down.sh
# ==============
# Что делаем: сносим стенд целиком. Идемпотентен — можно звать сколько угодно.
#
# Удаление namespace удаляет и всё, что в нём жило: veth-концы (вторые концы
# пропадают автоматически), адреса, маршруты, iptables, ipset, conntrack.
# Процессы сами не умирают — их убиваем явно через `ip netns pids`.

set -uo pipefail
source "$(dirname "$0")/lab-env.sh"

for ns in "$NS_C" "$NS_R" "$NS_S"; do
    if [[ -e /run/netns/$ns ]]; then
        # ip netns pids <ns> — PID-ы всех процессов, живущих в этом ns.
        pids=$(sudo ip netns pids "$ns" 2>/dev/null || true)
        [[ -n "$pids" ]] && sudo kill $pids 2>/dev/null
        sudo ip netns del "$ns" && echo "✓ удалён ns $ns"
    fi
done
rm -rf "$LAB_DIR"
echo "✓ Стенд снесён. iptables самой VM мы не трогали."
